package com.hcl.ManyToManyByUsingSpringDataJpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ManyToManyByUsingSpringDataJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
