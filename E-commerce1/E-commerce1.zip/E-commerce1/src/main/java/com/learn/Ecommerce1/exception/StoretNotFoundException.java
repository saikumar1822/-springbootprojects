package com.learn.Ecommerce1.exception;

public class StoretNotFoundException extends Exception {

	public StoretNotFoundException(String string) {
		// TODO Auto-generated constructor stub
	}

}
