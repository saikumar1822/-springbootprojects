package com.learn.Ecommerce.exceptions;

public class ProductNameNotFoundException extends Exception {

	public ProductNameNotFoundException(String productName) {
		// TODO Auto-generated constructor stub
	}

}
