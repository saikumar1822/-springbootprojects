package com.example.StudentService.exceptions;

public class NoCourseFoundException extends RuntimeException {
	public NoCourseFoundException() {
		super("NoCourseFoundException");
	}

}
