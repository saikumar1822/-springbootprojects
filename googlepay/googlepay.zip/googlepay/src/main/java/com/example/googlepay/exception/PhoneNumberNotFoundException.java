package com.example.googlepay.exception;

public class PhoneNumberNotFoundException extends Exception {

	public PhoneNumberNotFoundException(String string) {
		super(string);
	}

}
