package com.example.employeeparking.exception;

public class NoFreeSpotsFoundException extends Exception {
	public NoFreeSpotsFoundException(String s){
		
	}

}
