package com.example.googlepay;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GooglepayApplicationTests {

	@Test
	void contextLoads() {
	}

}
