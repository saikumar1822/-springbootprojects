package com.example.BankingApplication1.exceptions;

public class SavingsAccountIdNotFoundException extends RuntimeException {

}
