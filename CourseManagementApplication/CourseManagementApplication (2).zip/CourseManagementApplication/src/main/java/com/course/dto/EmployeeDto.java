package com.course.dto;

public class EmployeeDto {

}
