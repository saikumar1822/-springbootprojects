package com.learn.Ecommerce.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.learn.Ecommerce.dto.StoreReviewDto;
import com.learn.Ecommerce.exceptions.StoretNotFoundException;
import com.learn.Ecommerce.exceptions.UserNotFoundException;
import com.learn.Ecommerce.model.Product;
import com.learn.Ecommerce.model.Store;
import com.learn.Ecommerce.model.User;
import com.learn.Ecommerce.repository.StoreRepository;
import com.learn.Ecommerce.repository.UserRepository;

@Service
public class StoreReviewService {
	@Autowired

	UserRepository userRepository;

	@Autowired
	StoreRepository storeRepository;

	public String createReview(StoreReviewDto storeReviewDto) throws UserNotFoundException, StoretNotFoundException {

		User user = new User();

		user = userRepository.findById(storeReviewDto.getUserId())
				.orElseThrow(() -> new UserNotFoundException("user with given id not found"));

		Product product = new Product();

		product.setId(storeReviewDto.getProductId());

		Store store = storeRepository.findById(storeReviewDto.getStoreId())
				.orElseThrow(() -> new StoretNotFoundException("store Id not found"));

		Store storeReview = new Store();
		storeReview.setStoreName(store.getStoreName());
		
		storeReview.setStoreId(storeReviewDto.getStoreId());

		storeReview.setFeedBack(storeReviewDto.getFeedBack());

		storeReview.setRating(storeReviewDto.getRating());

		storeReview.setProduct(product);

		storeRepository.save(storeReview);

		return "store review successfully given";

	}

}
