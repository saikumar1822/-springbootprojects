package com.product.SpringDataJpaUsingCustomQueries.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.product.SpringDataJpaUsingCustomQueries.model.Product;
import com.product.SpringDataJpaUsingCustomQueries.service.ProductService;

@RestController
public class ProductController {
	@Autowired
	private ProductService productService;

	@GetMapping("welcome1")
	private String method1() {
		return "welcome to spring boot appliction";
	}

	@GetMapping("product/{pId}")
	private Product getProduct(@PathVariable int pId) {
		return productService.get(pId);
	}

	@PostMapping("product")
	private int saveProduct(@RequestBody Product product) {
		productService.save(product);
		return product.getpId();
	}

	@PutMapping("product")
	private int UpdateProduct(@RequestBody Product product) {
		productService.save(product);
		return product.getpId();
	}

	@DeleteMapping("product/{pId}")
	private int deleteEmployeeAttendance(@PathVariable int pId) {
		productService.delete(pId);
		return pId;
	}
	
	@GetMapping("products")
	private List<Product> getProducts() {
		return productService.listAll();
	}
	
	@GetMapping("products1/{pName}")
	private List<Product> findbypnameContaining(@PathVariable String pName) {
		System.out.println( pName);
		return productService.findByPNameContaining(pName);
	}
	
	@GetMapping("products2/{pName}")
	private List<Product> findbypnameLike(@PathVariable String pName) {
		System.out.println( pName);
		return productService.findByPNameLike(pName);
	}
	
	@GetMapping("products3/{price}")
	private List<Product> findBypriceLessThanEqual(@PathVariable String price) {
		
		return productService.findBypriceLessThanEqual(price);
	}
	
	@GetMapping("products4/{price}")
	private List<Product> findBypriceGretearThanEqual(@PathVariable String price) {
		
		return productService.findBypriceGreaterThanEqual(price);
	}
	
	@GetMapping("products5/{pName}")
	private List<Product> findBypNameStartingWith(@PathVariable String pName) {
		
		return productService.findBypNameStartingWith(pName);
	}

}
