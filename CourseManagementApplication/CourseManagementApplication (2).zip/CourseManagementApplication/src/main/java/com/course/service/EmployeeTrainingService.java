package com.course.service;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.course.model.Course;
import com.course.model.Training;
import com.course.repository.CourseRepository;
import com.course.repository.EmployeeTrainingRepository;

/**
 * 
 * @author sai
 * version 1.1
 * 
 *
 */
@Service
public class EmployeeTrainingService {
	
	@Autowired
	CourseRepository courseRepository;
	
	@Autowired
	EmployeeTrainingRepository employeeTrainingRepository;
	
	public List<Training> getAll(String courseName){
		Course course=courseRepository.findByCourseName(courseName);
		LocalDate d=LocalDate.now();
		List<Training>list=employeeTrainingRepository.findByCourseAndStartDateGreaterThanEqual(course,d);
	//	List<Training> compareTo=list.stream().sorted((i1,i2)->-i2.getStartDate().compareTo(i1.getStartDate())).collect(Collectors.toList());
		return list;
		
	}
	

}
