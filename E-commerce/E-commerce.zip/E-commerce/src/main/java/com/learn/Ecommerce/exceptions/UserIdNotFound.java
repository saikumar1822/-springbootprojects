package com.learn.Ecommerce.exceptions;

public class UserIdNotFound extends Exception {

	public UserIdNotFound(String string) {
	}

}
