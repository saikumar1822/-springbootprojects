package com.product.SpringDataJpaUsingCustomQueries.Exception;

public class InavalidCredentials extends RuntimeException {
	public InavalidCredentials() {
		super("invalidCredentials");
	}
	

}
