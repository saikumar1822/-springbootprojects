package com.example.googlepay.exception;

public class UserNotFoundException extends Exception {
	 public UserNotFoundException(String string) {

		 super(string);
	 }
}
