package com.example.Eurekha;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurekhaApplicationTests {

	@Test
	void contextLoads() {
	}

}
