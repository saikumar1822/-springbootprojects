package com.example.googlepay.exception;

public class CustomerNotFoundException extends Exception {
	public CustomerNotFoundException(String string) {
		super(string);
	}

}
