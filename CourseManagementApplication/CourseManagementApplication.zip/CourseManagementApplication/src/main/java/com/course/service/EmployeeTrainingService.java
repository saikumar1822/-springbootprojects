package com.course.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.course.model.Course;
import com.course.model.Employee;
import com.course.model.Training;
import com.course.repository.CourseRepository;
import com.course.repository.EmployeeTrainingRepository;


@Service
public class EmployeeTrainingService {
	
	@Autowired
	CourseRepository courseRepository;
	
	@Autowired
	EmployeeTrainingRepository employeeTrainingRepository;
	
	public List<Training> getAll(String courseName){
		Course course=courseRepository.findByCourseName(courseName);
		List<Training>list=employeeTrainingRepository.findByCourse(course);
		List<Training> compareTo=list.stream().sorted((i1,i2)->-i2.getStartDate().compareTo(i1.getStartDate())).collect(Collectors.toList());
		return compareTo;
		
	}
	

}
