package com.example.employeeparking.exception;

public class RequestNotProcessedException extends Exception {

	public RequestNotProcessedException(String string) {
	}

}
