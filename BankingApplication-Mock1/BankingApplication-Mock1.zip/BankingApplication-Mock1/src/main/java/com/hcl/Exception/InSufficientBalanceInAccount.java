package com.hcl.Exception;

public class InSufficientBalanceInAccount extends RuntimeException {



}
