package com.learn.Ecommerce.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.learn.Ecommerce.dto.ProductReviewDto;
import com.learn.Ecommerce.exceptions.ProductNotFound;
import com.learn.Ecommerce.exceptions.UserIdNotFound;
import com.learn.Ecommerce.model.Product;
import com.learn.Ecommerce.model.ProductReview;
import com.learn.Ecommerce.model.User;
import com.learn.Ecommerce.repository.OrderRepository;
import com.learn.Ecommerce.repository.ProductRepository;
import com.learn.Ecommerce.repository.ProductReviewRepository;
import com.learn.Ecommerce.repository.UserRepository;
@Service
public class ProductReviewService {
	 @Autowired

	 UserRepository userRepository;

	 @Autowired

	 ProductRepository productRepository;

	 @Autowired

	 ProductReviewRepository productReviewRepository;

	 @Autowired

	 OrderRepository orderRepository;

	 public String createReview(ProductReviewDto productReviewDto) throws UserIdNotFound, ProductNotFound {

	 User user = new User();

	 user=userRepository.findById(productReviewDto.getUserId()).orElseThrow(()->new UserIdNotFound("user with given id not found"));

	

	  Product product=productRepository.findById(productReviewDto.getProductId()).orElseThrow(()->new ProductNotFound("product not found"));

	  ProductReview productReview=new ProductReview();

	  productReview.setFeedBack(productReviewDto.getFeedBack());

	  productReview.setRating(productReviewDto.getRating());

	  productReview.setProduct(product);

	  productReviewRepository.save(productReview);

	  return "product review successfully given";

	 }

	

	 

}
