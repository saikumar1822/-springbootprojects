package com.learn.Ecommerce.exceptions;

public class UserNotFoundException extends Exception {

	public UserNotFoundException(String string) {
		super(string);
	}

}
