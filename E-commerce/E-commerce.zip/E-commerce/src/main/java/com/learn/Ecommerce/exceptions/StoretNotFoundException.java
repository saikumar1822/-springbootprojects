package com.learn.Ecommerce.exceptions;

public class StoretNotFoundException extends Exception {

	public StoretNotFoundException(String string) {
		// TODO Auto-generated constructor stub
	}

}
