package com.example.googlepay.exception;

public class RegistarionFailedException extends Exception {
	 public RegistarionFailedException() {

		 super("already registered");

		 }
}
