package com.learn.Ecommerce1.exception;

public class ProductNotFound extends Exception {

	public ProductNotFound(String string) {
	}

}
