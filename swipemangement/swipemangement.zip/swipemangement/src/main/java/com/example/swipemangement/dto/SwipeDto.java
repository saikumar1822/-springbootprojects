package com.example.swipemangement.dto;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.example.swipemangement.model.Employee;
import com.example.swipemangement.model.Facility;
import com.fasterxml.jackson.annotation.JsonIgnore;

public class SwipeDto {
	@Temporal(TemporalType.TIME)
	private Date swipeIn;
	@Temporal(TemporalType.TIME)
	private Date swipeOut;
	@JsonIgnore
	private double totalWorkingHours;

	@ManyToOne(cascade = CascadeType.ALL)
	private Facility facility;

	@ManyToOne(cascade = CascadeType.ALL)
	private Employee employee;


	public Date getSwipeIn() {
		return swipeIn;
	}

	public void setSwipeIn(Date swipeIn) {
		this.swipeIn = swipeIn;
	}

	public Date getSwipeOut() {
		return swipeOut;
	}

	public void setSwipeOut(Date swipeOut) {
		this.swipeOut = swipeOut;
	}

	public double getTotalWorkingHours() {
		return totalWorkingHours;
	}

	public void setTotalWorkingHours(double totalWorkingHours) {
		this.totalWorkingHours = totalWorkingHours;
	}

	public Facility getFacility() {
		return facility;
	}

	public void setFacility(Facility facility) {
		this.facility = facility;
	}

	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}

}
