package com.course.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.course.model.Training;
import com.course.service.EmployeeTrainingService;


@RestController
public class EmployeeTrainingController {
	@Autowired
	EmployeeTrainingService employeeTrainingService;
	
	@GetMapping("/course")
	public List<Training> get(@RequestParam String courseName){
		List<Training>list=employeeTrainingService.getAll(courseName);
		//List<EmployeeTraining> compareTo=list.stream().sorted((i1,i2)->-i2.getTraining().getStartDate().compareTo(i1.getTraining().getStartDate())).collect(Collectors.toList());
		return list;
	}

}
