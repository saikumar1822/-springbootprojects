package com.product.SpringDataJpaUsingCustomQueries;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDataJpaUsingCustomQueriesApplicationTests {

	@Test
	void contextLoads() {
	}

}
