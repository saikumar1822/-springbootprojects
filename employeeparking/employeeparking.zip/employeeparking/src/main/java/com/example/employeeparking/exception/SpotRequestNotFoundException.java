package com.example.employeeparking.exception;

public class SpotRequestNotFoundException extends Exception {
	public SpotRequestNotFoundException(String s) {
		
	}

}
