package com.learn.Ecommerce1.exception;

public class ProductNameNotFoundException extends Exception {

	public ProductNameNotFoundException(String productName) {
		// TODO Auto-generated constructor stub
	}

}
