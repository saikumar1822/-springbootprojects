package com.example.hungerbox.exception;

public class PaymentNotSuccessfulException extends Exception {
	public PaymentNotSuccessfulException(String s) {
		
	}
}
