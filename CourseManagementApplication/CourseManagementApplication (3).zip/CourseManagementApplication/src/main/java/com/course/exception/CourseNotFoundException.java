package com.course.exception;

public class CourseNotFoundException extends Exception {

	public CourseNotFoundException(String string) {
	}

}
