package com.student.student.exceptions;

public class NullStudentDataFoundException extends RuntimeException {
	public NullStudentDataFoundException() {
		super("NullStudentDataFoundException");
	}

}
