package com.learn.Ecommerce1.exception;

public class InvalidCredentials extends RuntimeException {

}
