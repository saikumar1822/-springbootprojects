package com.learn.Ecommerce.exceptions;

public class ProductNotFound extends Exception {

	public ProductNotFound(String string) {
	}

}
