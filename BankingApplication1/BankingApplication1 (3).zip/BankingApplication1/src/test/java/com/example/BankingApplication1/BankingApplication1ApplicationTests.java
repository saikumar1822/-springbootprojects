package com.example.BankingApplication1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankingApplication1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
