package com.hcl;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankingAppApplicationTests {


}
