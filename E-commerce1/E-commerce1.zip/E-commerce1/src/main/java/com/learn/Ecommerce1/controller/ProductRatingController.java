package com.learn.Ecommerce1.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.learn.Ecommerce1.exception.ProductNameNotFoundException;
import com.learn.Ecommerce1.model.ProductRating;
import com.learn.Ecommerce1.service.ProductReviewService;
@RestController
public class ProductRatingController {
	@Autowired
	ProductReviewService productReviewService;
	@PostMapping("/productRating")
	public ResponseEntity<ProductRating> ReviewStore(@RequestBody ProductRating productRating)
			throws ProductNameNotFoundException {

		ProductRating product=productReviewService.save(productRating);

		return new ResponseEntity<ProductRating>(product, HttpStatus.OK);

	}

}


