package com.hcl.ManyToManyByUsingSpringDataJpa.exceptions;

public class NullStudentDataFoundException extends RuntimeException {
	public NullStudentDataFoundException() {
		super("NullStudentDataFoundException");
	}

}
