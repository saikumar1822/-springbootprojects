package com.example.BankingApplication1.exceptions;

public class CustomerNotFoundException extends Exception {
	public CustomerNotFoundException(String string) {
		super(string);
	}

}
