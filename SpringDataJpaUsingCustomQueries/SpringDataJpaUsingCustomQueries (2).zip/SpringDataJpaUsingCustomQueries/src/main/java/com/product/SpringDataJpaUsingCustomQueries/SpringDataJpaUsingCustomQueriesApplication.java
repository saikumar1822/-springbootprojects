package com.product.SpringDataJpaUsingCustomQueries;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringDataJpaUsingCustomQueriesApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringDataJpaUsingCustomQueriesApplication.class, args);
	}

}
