package com.course.exception;

public class TrainingsListNotFoundException extends Exception {
	public TrainingsListNotFoundException(String s){
		
	}
}
