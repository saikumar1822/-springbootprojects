package com.student.student.exceptions;

public class NullDataFOundInCourseException extends RuntimeException {
	public NullDataFOundInCourseException() {
		super("Null Data FOund In Course Exception");
	}

}
