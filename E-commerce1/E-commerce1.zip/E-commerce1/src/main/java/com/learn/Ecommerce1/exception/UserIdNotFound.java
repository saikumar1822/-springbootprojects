package com.learn.Ecommerce1.exception;

public class UserIdNotFound extends Exception {

	public UserIdNotFound(String string) {
	}

}
