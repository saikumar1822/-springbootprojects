package com.learn.Ecommerce.dto;

public class StoreReviewDto {
	private long userId;

	private int storeId;

	private int productId;

	private double rating;

	private String feedBack;

	public long getUserId() {

		return userId;

	}

	public void setUserId(long userId) {

		this.userId = userId;

	}

	public int getStoreId() {

		return storeId;

	}

	public void setStoreId(int storeId) {

		this.storeId = storeId;

	}

	public double getRating() {

		return rating;

	}

	public void setRating(double rating) {

		this.rating = rating;

	}

	public String getFeedBack() {

		return feedBack;

	}

	public void setFeedBack(String feedBack) {

		this.feedBack = feedBack;

	}

	public int getProductId() {

		return productId;

	}

	public void setProductId(int productId) {

		this.productId = productId;

	}

}
