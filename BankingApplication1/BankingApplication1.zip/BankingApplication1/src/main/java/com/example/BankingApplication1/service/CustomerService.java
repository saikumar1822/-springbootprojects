package com.example.BankingApplication1.service;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.BankingApplication1.dto.CustomerDto;
import com.example.BankingApplication1.exceptions.InavalidCredentials;
import com.example.BankingApplication1.exceptions.InsufficientCustomerDetails;
import com.example.BankingApplication1.model.Customer;
import com.example.BankingApplication1.repository.CustomerRepository;

@Service
public class CustomerService {
	@Autowired
	CustomerRepository customerRepository;
	
	

	public CustomerDto customerRegistration(Customer customer) {
		if (customer.getPassword() != null) {
			customer =customerRepository.save(customer);
			CustomerDto customerDto=new CustomerDto();
			customerDto.setEmail(customer.getEmail());
			customerDto.setPassword(customer.getPassword());
			return customerDto;
		} else {
			throw new InsufficientCustomerDetails();
		}
	}

	public Customer UpdateCustomer(Customer customer) {
		if (customer.getPassword() != null) {
			return customerRepository.save(customer);
		} else {
			throw new InsufficientCustomerDetails();
		}
	}

	public Customer customerLogin(String email, String password) {
		
		Customer customer=customerRepository.findByEmailAndPassword(email, password);
		if(customer==null) {
			throw new InavalidCredentials();
		}
		return customer;
	}

	public Customer getCustomerById(long id) {

		return customerRepository.findById(id).get();
	}
}
