package com.example.cabbooking.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.cabbooking.model.Cab;
import com.example.cabbooking.repository.CabRepository;

@Service
public class CabService {
	
	@Autowired
	CabRepository cabRepository;
	
	public List< Cab> save() {
		return cabRepository.findByTimeStampGreaterThan( new Date());
		
	}
	
	public void cabSave(Cab cab) {
		cabRepository.save(cab);
	}

}
