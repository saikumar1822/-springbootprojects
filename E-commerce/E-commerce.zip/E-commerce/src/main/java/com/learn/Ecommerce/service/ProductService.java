package com.learn.Ecommerce.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.learn.Ecommerce.exceptions.ProductNameNotFoundException;
import com.learn.Ecommerce.model.Product;
import com.learn.Ecommerce.model.ProductReview;
import com.learn.Ecommerce.model.Store;
import com.learn.Ecommerce.repository.ProductRepository;
import com.learn.Ecommerce.repository.ProductReviewRepository;

@Service
public class ProductService {
	@Autowired

	ProductRepository productRepository;
	
	@Autowired
	ProductReviewRepository productReviewRepository ;

	public List<Product> viewProductByName(String productName) throws ProductNameNotFoundException {

		List<Product> products = productRepository.findByNameLike("%" + productName + "%");
	
		if (products.isEmpty()) {

			throw new ProductNameNotFoundException(productName);

		} else {
			
		
		//List<List<Store>> store=products.stream().map(m->m.getStoreList()).collect(Collectors.toList());
		
		return products;
		}
			
	}
	public Product getProduct(String productName) throws ProductNameNotFoundException {
		try {
			
		Product product= productRepository.findByName(productName);
		
		  List<ProductReview> p1=product.getProductReviewList(); List<ProductReview>
		  v1=p1.stream().sorted((i1,i2)->-i1.getRating().compareTo(i2.getRating())).
		  collect(Collectors.toList());
		  product.setProductReviewList(v1);
		 
		 List<Store> p=product.getStoreList();
		 List<Store> v=p.stream().sorted((i1,i2)->-i1.getRating().compareTo(i2.getRating())).collect(Collectors.toList());
		 product.setStoreList(v);
		 
		return product;
		}catch(Exception e) {
			throw new ProductNameNotFoundException(productName);
		}
	}

	
}
