package com.product.SpringDataJpaUsingCustomQueries.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.product.SpringDataJpaUsingCustomQueries.Exception.NoDataFoundException;
import com.product.SpringDataJpaUsingCustomQueries.Exception.ProductNotFoundException;
import com.product.SpringDataJpaUsingCustomQueries.model.Product;
import com.product.SpringDataJpaUsingCustomQueries.repository.ProductRepository;

@Service
public class ProductService {
	
	@Autowired
	private ProductRepository productRepository;
	
	public Product get(int pId) {
try {
	 return  productRepository.findById(pId).get();
}
catch(Exception e){
		throw new ProductNotFoundException(pId);
	}
	}

	public void save(Product product) {

		productRepository.save(product);
	}

	public void delete(int pId) {

		productRepository.deleteById(pId);
	}

	public List<Product> listAll() {

		List<Product> products= productRepository.findAll();
		if(products.isEmpty()) {
			throw new NoDataFoundException();
		}
		return products;
		
	}

	public List<Product> findByPNameContaining(String pName) {

		return productRepository.findBypNameContaining(pName);
	}

	public List<Product> findByPNameLike(String pName) {

		return productRepository.findBypNameLike(pName);
	}
	
	public List<Product> findBypriceLessThanEqual(String price) {

		return productRepository.findBypriceLessThanEqual(price);
	}
	
	public List<Product> findBypriceGreaterThanEqual(String price) {

		return productRepository.findBypriceGreaterThanEqual(price);
	}
	
	public List<Product> findBypNameStartingWith(String pName) {

		return productRepository.findBypNameStartingWith(pName);
	}
	
	
	



}
