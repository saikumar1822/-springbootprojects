package com.learn.Ecommerce1.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.learn.Ecommerce1.model.Product;
import com.learn.Ecommerce1.model.ProductRating;
import com.learn.Ecommerce1.repository.ProductRepository;
import com.learn.Ecommerce1.repository.ProductReviewRepository;

@Service
public class ProductReviewService {
@Autowired
ProductReviewRepository productReviewRepository ;

@Autowired
ProductRepository productRepository;

	public ProductRating save(ProductRating productRating) {
		Product product=productRepository.findById(productRating.getProduct().getproductId()).get();
		 productReviewRepository.save(productRating);
		List<ProductRating> p= productReviewRepository.findByProduct(product);
		
		 double count= p.stream().count();
		  List<Double> d = p.stream().map(x -> x.getRating()).collect(Collectors.toList());
		  double sum = d.stream().mapToDouble(Double::doubleValue).sum();
		  product.setRating(sum/count);

		  productRepository.save(product);
		return productRating;
	}

}
