package com.example.StudentService.exceptions;

public class NullStudentDataFoundException extends RuntimeException {
	public NullStudentDataFoundException() {
		super("NullStudentDataFoundException");
	}

}
