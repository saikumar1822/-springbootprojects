package com.example.swipemangement.exception;

public class NoFacilityDataFoundException extends Exception {

}
