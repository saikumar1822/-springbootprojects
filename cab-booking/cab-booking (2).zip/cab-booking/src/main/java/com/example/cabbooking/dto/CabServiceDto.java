package com.example.cabbooking.dto;

import java.util.List;


import com.example.cabbooking.model.Cab;

public class CabServiceDto {
	
	
	private List<Cab> cabs;

	public List<Cab> getCabs() {
		return cabs;
	}

	public void setCabs(List<Cab> cabs) {
		this.cabs = cabs;
	}
	

}
