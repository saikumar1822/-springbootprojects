package com.example.googlepay.exception;

public class AmountNotFoundException extends Exception {
	public AmountNotFoundException(String string) {
		super(string);
	}

}
