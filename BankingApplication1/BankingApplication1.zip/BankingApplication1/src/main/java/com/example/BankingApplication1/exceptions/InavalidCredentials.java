package com.example.BankingApplication1.exceptions;

public class InavalidCredentials extends RuntimeException {

}
