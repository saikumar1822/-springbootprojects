package com.example.BankingApplication1.exceptions;

public class CustomerNotLoggedIn extends RuntimeException {

}
