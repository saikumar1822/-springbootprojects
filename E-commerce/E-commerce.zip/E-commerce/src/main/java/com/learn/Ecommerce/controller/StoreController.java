package com.learn.Ecommerce.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.learn.Ecommerce.dto.ResponseDto;
import com.learn.Ecommerce.dto.StoreReviewDto;
import com.learn.Ecommerce.exceptions.StoretNotFoundException;
import com.learn.Ecommerce.exceptions.UserNotFoundException;
import com.learn.Ecommerce.service.StoreReviewService;

@RestController
public class StoreController {
	 @Autowired

	 StoreReviewService storeReviewService;



	 @PostMapping("/storeReview")

	 public ResponseDto createReview(@RequestBody StoreReviewDto storeReviewDto) throws UserNotFoundException, StoretNotFoundException {

	 ResponseDto responseDto=new ResponseDto();

	 String message=storeReviewService.createReview(storeReviewDto);

	 responseDto.setMessage(message);

	 return responseDto;

	 }





}
