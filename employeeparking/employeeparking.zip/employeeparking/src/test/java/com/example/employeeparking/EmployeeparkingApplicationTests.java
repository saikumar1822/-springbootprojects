package com.example.employeeparking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeparkingApplicationTests {

	@Test
	void contextLoads() {
	}

}
