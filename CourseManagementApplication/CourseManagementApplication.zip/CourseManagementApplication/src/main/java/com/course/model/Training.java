package com.course.model;

import java.time.LocalDate;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table
public class Training {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long trainingId;

	@NotEmpty(message = "Batch num is required")
	private String batchname;

	@NotEmpty(message = "start date is required")
	private LocalDate startDate;

	@NotEmpty(message = "end date is required")
	private LocalDate endDate;
	@OneToMany
    private List<Employee> employee;
	private String redgStatus;
	public List<Employee> getEmployee() {
		return employee;
	}

	public void setEmployee(List<Employee> employee) {
		this.employee = employee;
	}

	@JsonIgnore
	@ManyToOne()
	private Course course;

	public long getTrainingId() {
		return trainingId;
	}

	public void setTrainingId(long trainingId) {
		this.trainingId = trainingId;
	}

	

	public String getBatchname() {
		return batchname;
	}

	public void setBatchname(String batchname) {
		this.batchname = batchname;
	}

	public LocalDate getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}

	public LocalDate getEndDate() {
		return endDate;
	}

	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}

	public Course getCourse() {
		return course;
	}

	public void setCourse(Course course) {
		this.course = course;
	}

	public String getRedgStatus() {
		return redgStatus;
	}

	public void setRedgStatus(String redgStatus) {
		this.redgStatus = redgStatus;
	}

}
