package com.example.hungerbox.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.hungerbox.dto.OrderDto;
import com.example.hungerbox.dto.ResponseDto;
import com.example.hungerbox.model.Employee;
import com.example.hungerbox.model.Item;
import com.example.hungerbox.model.Order;
import com.example.hungerbox.model.OrderItemList;
import com.example.hungerbox.repository.EmployeeRepository;
import com.example.hungerbox.repository.ItemRepositroy;
import com.example.hungerbox.repository.OrderItemListRepository;
import com.example.hungerbox.repository.OrderRepository;

@Service
public class OrderService {

	@Autowired
	OrderRepository orderRepository;

	@Autowired
	OrderItemListRepository orderItemListRepository;

	@Autowired

	EmployeeRepository employeeRepository;

	@Autowired
	ItemRepositroy itemRepositroy;

	public ResponseDto saveOrder(OrderDto orderDto) {

		Employee employee = employeeRepository.findById(orderDto.getEmployeeId()).get();
		Order order = new Order();
		order.setEmployee(employee);

		order = orderRepository.save(order);

		List<Long> itemIds = orderDto.getItemDto().stream().map(m -> m.getItemId()).collect(Collectors.toList());
		List<Integer> quantity = orderDto.getItemDto().stream().map(m -> m.getQuantity()).collect(Collectors.toList());
		double totalPrice = 0;
		for (int i = 0; i < itemIds.size(); i++) {
			Item item = itemRepositroy.findById(itemIds.get(i)).get();
			OrderItemList orderItemList = new OrderItemList();
			orderItemList.setOrder(order);

			totalPrice = totalPrice + (quantity.get(i) * item.getUnitPrice());

			orderItemList.setQuantity(quantity.get(i));
			orderItemList.setItem(item);

			orderItemListRepository.save(orderItemList);
		}
		order.setOrderPrice(totalPrice);
		orderRepository.save(order);
		ResponseDto d = new ResponseDto();
		d.setMessage("sucess");
		return d;
	}

}
