package com.example.cabbooking.exceptions;

public class UserIdNotFound extends Exception {

	public UserIdNotFound(String string) {
	}

}
