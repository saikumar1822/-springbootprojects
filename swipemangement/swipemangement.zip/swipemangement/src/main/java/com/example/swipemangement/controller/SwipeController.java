package com.example.swipemangement.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.swipemangement.dto.ResponseDto;
import com.example.swipemangement.dto.SwipeDto;
import com.example.swipemangement.model.Employee;
import com.example.swipemangement.model.Swipe;
import com.example.swipemangement.service.SwipeService;


@RestController
public class SwipeController {
	@Autowired
	SwipeService swipeService;
	
	@PostMapping("/swipe")
	public ResponseEntity<ResponseDto> createSwipe(@RequestBody SwipeDto swipeDto) {
		ResponseDto responseDto=new ResponseDto();
		swipeService.save(swipeDto);
		responseDto.setMessage("swipe saved successfully");
		responseDto.getMessage();
		return new ResponseEntity<ResponseDto>(responseDto, HttpStatus.OK);	
	}

	@PostMapping("")
	public ResponseEntity<String> getSwipeReportByEmployeeId(@RequestParam long id) {
		ResponseDto responseDto=new ResponseDto();
		String swipe=swipeService.getSwipeEmployee(id);
		responseDto.setMessage("swipe saved successfully");
		responseDto.getMessage();
		return new ResponseEntity<String>(swipe, HttpStatus.OK);	
	}

}


