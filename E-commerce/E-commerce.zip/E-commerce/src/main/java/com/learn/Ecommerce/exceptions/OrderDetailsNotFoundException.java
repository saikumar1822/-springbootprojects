package com.learn.Ecommerce.exceptions;

public class OrderDetailsNotFoundException extends Exception {

}
