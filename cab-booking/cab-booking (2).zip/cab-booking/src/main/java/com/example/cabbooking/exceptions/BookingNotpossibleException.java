package com.example.cabbooking.exceptions;

public class BookingNotpossibleException extends Exception {

	public BookingNotpossibleException(String string) {
	}

}
