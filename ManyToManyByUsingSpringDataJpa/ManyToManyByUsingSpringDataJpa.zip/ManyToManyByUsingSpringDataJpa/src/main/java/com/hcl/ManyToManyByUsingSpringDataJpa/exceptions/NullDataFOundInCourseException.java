package com.hcl.ManyToManyByUsingSpringDataJpa.exceptions;

public class NullDataFOundInCourseException extends RuntimeException {
	public NullDataFOundInCourseException() {
		super("Null Data FOund In Course Exception");
	}

}
