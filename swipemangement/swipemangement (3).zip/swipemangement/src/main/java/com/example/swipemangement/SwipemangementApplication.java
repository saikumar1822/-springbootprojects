package com.example.swipemangement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SwipemangementApplication {

	public static void main(String[] args) {
		SpringApplication.run(SwipemangementApplication.class, args);
	}

}
