package com.example.cabbooking.exceptions;

public class NoCabsFoundException extends Exception {

	
	private static final long serialVersionUID = 1L;

	public NoCabsFoundException(String string) {
		
	}

}
