package com.example.hungerbox.exception;

public class OrderDetailsNotFoundException extends Exception {
public OrderDetailsNotFoundException(String s) {
	
}
}
