package com.learn.Ecommerce.exceptions;

public class InvalidCredentials extends RuntimeException {

}
