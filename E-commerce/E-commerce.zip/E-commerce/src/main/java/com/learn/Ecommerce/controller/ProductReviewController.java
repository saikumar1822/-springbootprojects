package com.learn.Ecommerce.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.learn.Ecommerce.dto.ProductReviewDto;
import com.learn.Ecommerce.dto.ProductReviewResponse;
import com.learn.Ecommerce.exceptions.ProductNotFound;
import com.learn.Ecommerce.exceptions.UserIdNotFound;
import com.learn.Ecommerce.service.ProductReviewService;

@RestController
public class ProductReviewController {
	 @Autowired

	 ProductReviewService productReviewService;

	 @PostMapping("/productReview")

	 public ProductReviewResponse createReview(@RequestBody ProductReviewDto productReviewDto) throws UserIdNotFound, ProductNotFound {

	 ProductReviewResponse productReviewResponse=new ProductReviewResponse();

	 String message=productReviewService.createReview(productReviewDto);

	 productReviewResponse.setMessage(message);

	 return productReviewResponse;

	 }

}
