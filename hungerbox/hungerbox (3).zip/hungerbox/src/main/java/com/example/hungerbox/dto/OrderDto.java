package com.example.hungerbox.dto;

import java.util.List;

public class OrderDto {
	public Long employeeId;
	public List<ItemDto> itemDto;
	public Long getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(Long employeeId) {
		this.employeeId = employeeId;
	}
	public List<ItemDto> getItemDto() {
		return itemDto;
	}
	public void setItemDto(List<ItemDto> itemDto) {
		this.itemDto = itemDto;
	}
	
}
