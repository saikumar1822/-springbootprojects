package com.learn.Ecommerce1.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.learn.Ecommerce1.model.Store;
import com.learn.Ecommerce1.model.StoreReview;
import com.learn.Ecommerce1.repository.StoreRepository;
import com.learn.Ecommerce1.repository.StoreReviewRepository;
@Service
public class StoreReviewService {
	@Autowired
	StoreReviewRepository storeReviewRepository;
	
	@Autowired
	StoreRepository storeRepository;
	
	
	public StoreReview save(StoreReview storeReview) {
		Store store=storeRepository.findById(storeReview.getStore().getStoreId()).get();
		storeReviewRepository.save(storeReview);
		List<StoreReview> r=storeReviewRepository.findByStore(store);
		 double count= r.stream().count();
		  List<Double> d = r.stream().map(x -> x.getRating()).collect(Collectors.toList());
		  double sum = d.stream().mapToDouble(Double::doubleValue).sum();
		  store.setRating(sum/count);
		  storeRepository.save(store);
		return storeReview;
	}

}
