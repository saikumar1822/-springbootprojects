package com.example.swipemangement.service;

import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.example.swipemangement.dto.SwipeDto;
import com.example.swipemangement.model.Employee;
import com.example.swipemangement.model.Swipe;
import com.example.swipemangement.repository.EmployeeRepository;
import com.example.swipemangement.repository.SwipeRepository;
@Service
public class SwipeService {
	@Autowired
	SwipeRepository swipeRepository;
	
	@Autowired
	EmployeeRepository employeeRepository;
	
	@Autowired
	RestTemplate restTemplate;
	
	@Bean
	public RestTemplate getRestTemplate() {
		return new RestTemplate();
	}
	
	public void save(SwipeDto swipeDto) {
		
		swipeDto.setTotalWorkingHours((swipeDto.getSwipeOut().getTime()-swipeDto.getSwipeIn().getTime())/(60*60*1000));
		Swipe swipe=new Swipe();
		BeanUtils.copyProperties(swipeDto, swipe);
		swipeRepository.save(swipe);
	}
	public Employee getSwipe(SwipeDto swipeDto) {
		 return employeeRepository.findById(swipeDto.getEmployee().getEmployeeId()).get();
		
	}
	
	public String getSwipeEmployee(Long id) {
		
		String result=restTemplate.getForObject("http://localhost:7890/employee/"+id ,String.class);
		return result;
}


}
