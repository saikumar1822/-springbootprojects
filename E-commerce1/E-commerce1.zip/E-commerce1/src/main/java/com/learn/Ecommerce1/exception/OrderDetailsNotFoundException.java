package com.learn.Ecommerce1.exception;

public class OrderDetailsNotFoundException extends Exception {

}
