package com.example.cabbooking.exceptions;


@SuppressWarnings("serial")
public class CabBookingHistoryNotFound extends RuntimeException{

}
