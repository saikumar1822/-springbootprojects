package com.learn.Ecommerce1.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.learn.Ecommerce1.model.Store;

public interface StoreRepository extends JpaRepository<Store, Long>{

}
