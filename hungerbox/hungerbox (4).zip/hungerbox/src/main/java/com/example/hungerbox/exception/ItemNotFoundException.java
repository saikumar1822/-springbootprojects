package com.example.hungerbox.exception;

public class ItemNotFoundException extends Exception{
public ItemNotFoundException(String s) {
	
}
}
