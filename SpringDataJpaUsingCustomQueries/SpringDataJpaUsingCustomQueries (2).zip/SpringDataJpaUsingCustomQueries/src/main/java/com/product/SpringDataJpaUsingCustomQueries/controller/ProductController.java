package com.product.SpringDataJpaUsingCustomQueries.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.product.SpringDataJpaUsingCustomQueries.Exception.ProductNotFoundException;
import com.product.SpringDataJpaUsingCustomQueries.model.Product;
import com.product.SpringDataJpaUsingCustomQueries.service.ProductService;

@RestController
public class ProductController {
	@Autowired
	private ProductService productService;

	@GetMapping("welcome1")
	private String method1() {
		return "welcome to spring boot appliction";
	}

	@GetMapping("product/{pId}")
	public Product getProduct(@PathVariable int pId) {
		return productService.findById(pId);
	}

	@PostMapping("product")
	public Product saveProduct(@RequestBody Product product) {
		return productService.save(product);
		
	}

	@PutMapping("product")
	public int UpdateProduct(@RequestBody Product product) {
		productService.save(product);
		return product.getpId();
	}

	@DeleteMapping("product/{pId}")
	public String deleteProduct(@PathVariable int pId) {
		return	productService.delete(pId);
		 
	}
	
	@GetMapping("products")
	public List<Product> ListAll() {
		return productService.listAll();
	}
	
	@GetMapping("products1/{pName}")
	public List<Product> findbypnameContaining(@PathVariable String pName) {
		System.out.println( pName);
		return productService.findByPNameContaining(pName);
	}
	
	@GetMapping("products2/{pName}")
	public List<Product> findbypnameLike(@PathVariable String pName) {
		System.out.println( pName);
		return productService.findByPNameLike(pName);
	}
	
	@GetMapping("products3/{price}")
	public List<Product> findBypriceLessThanEqual(@PathVariable String price) {
		
		return productService.findBypriceLessThanEqual(price);
	}
	
	@GetMapping("products4/{price}")
	public List<Product> findBypriceGretearThanEqual(@PathVariable String price) {
		
		return productService.findBypriceGreaterThanEqual(price);
	}
	
	@GetMapping("products5/{pName}")
	public List<Product> findBypNameStartingWith(@PathVariable String pName) {
		
		return productService.findBypNameStartingWith(pName);
	}

}
