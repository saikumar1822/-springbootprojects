package com.example.StudentService.exceptions;

public class NullDataFOundInCourseException extends RuntimeException {
	public NullDataFOundInCourseException() {
		super("Null Data FOund In Course Exception");
	}

}
