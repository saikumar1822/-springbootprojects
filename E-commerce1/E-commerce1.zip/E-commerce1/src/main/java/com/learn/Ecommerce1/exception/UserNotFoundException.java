package com.learn.Ecommerce1.exception;

public class UserNotFoundException extends Exception {

	public UserNotFoundException(String string) {
		super(string);
	}

}
