package com.example.cabbooking.exceptions;

public class CabNotFoundException extends Exception {

	public CabNotFoundException(String string) {
	}

}
