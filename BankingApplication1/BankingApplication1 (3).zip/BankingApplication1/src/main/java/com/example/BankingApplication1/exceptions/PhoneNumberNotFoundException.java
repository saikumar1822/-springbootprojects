package com.example.BankingApplication1.exceptions;

public class PhoneNumberNotFoundException extends Exception {

	public PhoneNumberNotFoundException(String string) {
		super(string);
	}

}
