package com.example.hungerbox.exception;

public class EmployeeNotFoundException extends Exception {
	public EmployeeNotFoundException(String s){
		
	}
}
