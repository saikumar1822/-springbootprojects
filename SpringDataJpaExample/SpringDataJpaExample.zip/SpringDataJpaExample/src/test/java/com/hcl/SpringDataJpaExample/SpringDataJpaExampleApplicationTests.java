package com.hcl.SpringDataJpaExample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDataJpaExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
