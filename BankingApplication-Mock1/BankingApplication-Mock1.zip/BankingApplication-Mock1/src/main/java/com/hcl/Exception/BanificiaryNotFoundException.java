package com.hcl.Exception;

public class BanificiaryNotFoundException extends RuntimeException {

	
	private static final long serialVersionUID = 1L;

}