package com.product.SpringDataJpaUsingCustomQueries.controller;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.product.SpringDataJpaUsingCustomQueries.Exception.ProductNotFoundException;
import com.product.SpringDataJpaUsingCustomQueries.model.Product;
import com.product.SpringDataJpaUsingCustomQueries.service.ProductService;

import junit.framework.Assert;

@RunWith(MockitoJUnitRunner.Silent.class)
public class ProductControllerTest {
	@InjectMocks
	ProductController productController;

	@Mock
	ProductService productService;

	MockMvc mockMvc;

	@Before
	public void setUp() {
		mockMvc = MockMvcBuilders.standaloneSetup(productController).build();
	}

	@Test
	public void testListAllMvc() throws Exception {

		List<Product> products = new ArrayList();

		Product product = new Product();
		product.setpId(2);
		product.setpName("samsung");
		product.setDescription("very good battery backup");
		product.setPrice("2000");
		product.setDate("1/2/2019");

		Mockito.when(productService.listAll()).thenReturn(products);

		MvcResult response = mockMvc.perform(MockMvcRequestBuilders.get("/products")).andReturn();
		String content = response.getResponse().getContentAsString();
		System.out.println(content);

	}
	@Test
	public void testSaveForPositive() {
		Product product = new Product();
		product.setpId(2);
		product.setpName("samsung");
		product.setDescription("very good battery backup");
		product.setPrice("2000");
		product.setDate("1/2/2019");
	Mockito.when(productService.save(Mockito.any(Product.class))).thenReturn((product));
		Product resProduct = productController.saveProduct(product);
		Assert.assertNotNull(resProduct);
		Assert.assertEquals(product.getpName(), resProduct.getpName());
	}
	
	@Test(expected = Exception.class)
	public void testSaveForNegitive() {
		Product product = new Product();
		product.setpId(2);
		product.setpName("samsung");
		product.setDescription("very good battery backup");
		product.setPrice("2000");
		product.setDate("1/2/2019");
		Mockito.when(productService.save(Mockito.any(Product.class))).thenThrow(Exception.class);
		Product resProduct = productController.saveProduct(product);
	}
	@Test
	public void testFindByIdForPositive() {
		Product product = new Product();
		product.setpId(1);
		product.setpName("samsung");
		product.setDescription("very good battery backup");
		product.setPrice("2000");
		product.setDate("1/2/2019");
		Mockito.when(productService.findById(Mockito.anyInt())).thenReturn(product);

		Product resProduct = productController.getProduct(1);
		Assert.assertNotNull(resProduct);
		Assert.assertEquals(product.getpName(), resProduct.getpName());
		Assert.assertEquals(product.getPrice(), resProduct.getPrice());
	}
	
	@Test
	public void testfindbypnameContainingForPositive() {
		List<Product> products = new ArrayList();

		Product product = new Product();
		product.setpId(1);
		product.setpName("samsung");
		product.setDescription("very good battery backup");
		product.setPrice("2000");
		product.setDate("1/2/2019");
		products.add(product);
		Mockito.when(productService.findByPNameContaining("samsung")).thenReturn(products);
		List<Product> products2 = productController.findbypnameContaining("samsung");
		Assert.assertNotNull(products2);
		Assert.assertEquals(products2.size(), products.size());
	}
	@Test(expected = Exception.class)
	public void testfindbypnameContainingForException() {
		Mockito.when(productService.findByPNameContaining("calculator")).thenThrow(Exception.class);
		List<Product> products2 = productController.findbypnameContaining("calculator");
	}
	
	@Test
	public void testfindbypnameLikeForPositive() {
		List<Product> products = new ArrayList();

		Product product = new Product();
		product.setpId(1);
		product.setpName("redmi");
		product.setDescription("very good battery backup");
		product.setPrice("2000");
		product.setDate("1/2/2019");
		products.add(product);
		Mockito.when(productService.findByPNameLike("redmi")).thenReturn(products);
		List<Product> products2 = productController.findbypnameLike("redmi");
		Assert.assertNotNull(products2);
		Assert.assertEquals(products.size(), products2.size());
	}
	
	@Test(expected = NullPointerException.class)
	public void testfindbypnameLikeForException() {
		Mockito.when(productService.findByPNameLike("iphone")).thenThrow(NullPointerException.class);
		List<Product> products2 = productController.findbypnameLike("iphone");
	}
	@Test
	public void testfindBypriceLessThanEqualForPositive() {
		List<Product> products = new ArrayList();

		Product product = new Product();
		product.setpId(1);
		product.setpName("realme");
		product.setDescription("very good battery backup");
		product.setPrice("2000");
		product.setDate("1/2/2019");
		products.add(product);
		Mockito.when(productService.findBypriceLessThanEqual("1234")).thenReturn(products);
		List<Product> products2 = productController.findBypriceLessThanEqual("1234");
		Assert.assertNotNull(products2);
		Assert.assertEquals(products.size(), products2.size());
	}
	
	@Test(expected = NumberFormatException.class)
	public void testfindBypriceLessThanEqualForExc() {
		Mockito.when(productService.findBypriceLessThanEqual("one hundard")).thenThrow(NumberFormatException.class);
		List<Product> products2 = productController.findBypriceLessThanEqual("one hundard");
		
	}
	@Test
    public void testDeleteForPositive() throws Exception {      
        Mockito.when(productService.delete(1)).thenReturn("succeess");
        mockMvc.perform(MockMvcRequestBuilders.delete("/product/1"))
                .andExpect(status().isOk());
    }
}
